<?php
	include('conn.php');
	$ticker=$_GET['id'];
	mysqli_query($conn,"DELETE FROM `stock` where ticker='$ticker'");
	header('location:investment.php');
?>