<div class="modal fade" role="dialog" tabindex="-1" id="addnew_stock">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Add Stock</h5>
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="py-1">
					<form class="form" method="POST" action="addnew_stock.php">
						<div class="row">
							<div class="col">
								<div class="form-group">
									<label>Symbol</label>
									<input class="form-control" type="text" name="ticker" id="ticker" value="">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col d-flex justify-content-end">
								<button class="btn btn-primary" type="submit">Add Stock</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>