<?php
	include('conn.php');
	
	if (isset($_POST['date_added'])) {
		$date_added = $_POST['date_added'];
	}
	if (isset($_POST['incexp'])) {
		$incexp = $_POST['incexp'];
	}
	if (isset($_POST['category'])) {
		$category = $_POST['category'];
	}
	if (isset($_POST['memo'])) {
		$memo = $_POST['memo'];
	}
	if (isset($_POST['amount'])) {
		$amount = $_POST['amount'];
	}
	mysqli_query($conn,"INSERT INTO `expense` (date_added,category,memo,amount)
	VALUES ('$date_added','$category','$memo','$amount')");
	header('location:expense.php');
?>