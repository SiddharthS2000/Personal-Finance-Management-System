<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Plutus</title>

    <!-- Bootstrap core CSS -->
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>


    <!-- Custom styles for this template -->
    <link href="assets/css/dashboard.css" rel="stylesheet">
</head>

<body>

    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="#">PLUTUS</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse" data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="expense.php">
                                Expense Manager
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                Retirement Calculator
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="investment.php">
                                Investment Portfolio
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>RETIREMENT PLANNER</h1>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <canvas id="chartretirement" width="900" height="380"></canvas>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <div class="jumbotron jumbotron-fluid">
                            <div class="container">
                                <h3>CURRENT PROJECTIONS</h3>
                                <hr>
                                <?php
                                include('conn.php');
                                $sql = "SELECT * FROM retire";
                                $query = mysqli_query($conn, $sql);
                                while ($row = mysqli_fetch_array($query)) {
                                    $ret_amount = '$ ' . number_format($row['ret_amount']);
                                    $ret_age = $row['ret_age'] .' years';
                                }
                                ?>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="form-row">
                                                    <div class="col">
                                                        <span style="font-size:1.8rem;">Retirement Corpus</span>
                                                    </div>
                                                    <div class="col">
                                                        <h3><span style="color:seagreen"><?php echo ucwords($ret_amount); ?></span></h3>
                                                        <span>This the expected corpus value at your age of retirement.</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="form-row">
                                                    <div class="col">
                                                        <span style="font-size:1.8rem;">Retirement Age</span>
                                                    </div>
                                                    <div class="col">
                                                        <h3><span style="color:seagreen"><?php echo ucwords($ret_age); ?></span></h3>
                                                        <span>Bounce Rate</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="my-3">
                <h2>When can you retire? Find out with our <span style="color:red">FIRE</span> Retirement Calculator.</h2>
                <div class="jumbotron">
                    <h1 class="display-4">Hello, Planner!</h1>
                    <p class="lead">FIRE is sweeping the nation. When can you retire? Find out with our FIRE Retirement Calculator</p>
                    <hr class="my-4">
                    <form class="form" method="POST" action="addnewretire.php">
                        <?php
                        $edit = mysqli_query($conn, "SELECT * from `retire` where `retirement_id`='1' ");
                        $erow = mysqli_fetch_array($edit);
                        ?>
                        <div class="form-row">
                            <div class="col">
                                <h4>How much is your retirement fund currently worth?</h4>
                                <div class="input-group mb-3">
                                    <span class="input-group-text">$</span>
                                    <input type="integer" class="form-control" name="net_worth" id="net_worth" placeholder="Current Net Worth" value="<?php echo $erow['net_worth']; ?>" required>
                                </div>
                                <div class="input-group mb-3">
                                    <div class="slidecontainer">
                                        <input type="range" min="10000" max="1000000" oninput="myFunction(this)" value="<?php echo $erow['net_worth']; ?>" step="10000" class="slider" id="netWorthRange" />
                                    </div>
                                </div>
                                <div id="helpBlock" class="form-text">
                                    In other words, the amount of money already saved for retirement as of today.
                                </div>
                            </div>
                            <div class="col">
                                <h4>How old are you?</h4>
                                <div class="input-group mb-3">
                                    <input type="integer" class="form-control" name="age" id="age" placeholder="Current Age" value="<?php echo $erow['age']; ?>" required>
                                    <span class="input-group-text">years</span>
                                </div>
                                <div class="input-group mb-3">
                                    <div class="slidecontainer">
                                        <input type="range" min="18" max="50" oninput="myFunction(this)" value="<?php echo $erow['age']; ?>" step="1" class="slider" id="ageRange" />
                                    </div>
                                </div>
                                <div id="helpBlock" class="form-text">
                                    Your current age
                                </div>
                            </div>
                        </div>
                        <hr class="my-3">
                        <div class="form-row">
                            <h4>How much are you contributing to your retirement fund per year?</h4>
                            <div class="input-group mb-3">
                                <span class="input-group-text">$</span>
                                <input type="number" class="form-control" name="contribution" id="contribution" placeholder="Retirement Fund Contribution" value="<?php echo $erow['contribution']; ?>" required>
                            </div>
                            <div class="input-group mb-3">
                                <div class="slidecontainer">
                                    <input type="range" min="5000" max="500000" oninput="myFunction(this)" value="<?php echo $erow['contribution']; ?>" step="1000" class="slider" id="contributionRange" />
                                </div>
                            </div>
                            <div id="helpBlock" class="form-text">
                                We anticipate this will increase at the rate of inflation until you retire.
                            </div>
                        </div>
                        <hr class="my-3">
                        <div class="form-row">
                            <h4>What's your target annual spend in retirement?</h4>
                            <div class="input-group mb-3">
                                <span class="input-group-text">$</span>
                                <input type="number" class="form-control" name="spend" id="spend" placeholder="Retirement Annual Spending" value="<?php echo $erow['spend']; ?>" required>
                            </div>
                            <div class="input-group mb-3">
                                <div class="slidecontainer">
                                    <input type="range" min="45000" max="500000" oninput="myFunction(this)" value="<?php echo $erow['spend']; ?>" step="5000" class="slider" id="spendRange" />
                                </div>
                            </div>
                            <div id="helpBlock" class="form-text">
                                In today's after-tax dollars, how much money do you want to spend per year in retirement? For a margin of safety, this value should be at least double your essential expenses.
                                Can you realistically live on this amount per month for an extended period if you needed to?
                            </div>
                        </div>
                        <hr class="my-4">
                        <hr class="my-4">
                        <div class="accordion" id="accordionAssumptions">
                            <div class="card">
                                <div class="card-header">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne">
                                            Market Assumptions
                                        </button>
                                    </h2>
                                </div>

                                <div id="collapseOne" class="collapse" data-parent="#accordionAssumptions">
                                    <div class="card-body">
                                        <div class="container">
                                            <h2>Market Assumptions</h2>
                                            <hr>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <h4>Return on investments</h4>
                                                    <div class="input-group mb-3">
                                                        <input type="number" class="form-control" name="roi" id="roi" placeholder="ROI" value="<?php echo $erow['roi']; ?>" required>
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                    <div class="input-group mb-3">
                                                        <div class="slidecontainer">
                                                            <input type="range" min="1" max="100" oninput="myFunction(this)" value="<?php echo $erow['roi']; ?>" step="1" class="slider" id="roiRange" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="helpBlock" class="col-lg-6 form-text">
                                                    The annual returns you anticipate to receive in the market over the long term.
                                                </div>
                                            </div>
                                            <hr class="my-3">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <h4>Inflation</h4>
                                                    <div class="input-group mb-3">
                                                        <input type="number" class="form-control" name="inflation" id="inflation" placeholder="Inflation" value="<?php echo $erow['inflation']; ?>" required>
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                    <div class="input-group mb-3">
                                                        <div class="slidecontainer">
                                                            <input type="range" min="1" max="100" oninput="myFunction(this)" value="<?php echo $erow['inflation']; ?>" step="1" class="slider" id="inflationRange" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="helpBlock" class="col-lg-6 form-text">
                                                    The annual rate of inflation you anticipate over the long term.
                                                </div>
                                            </div>
                                            <hr class="my-3">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <h4>Effective income tax in retirement</h4>
                                                    <div class="input-group mb-3">
                                                        <input type="number" class="form-control" name="inctax" id="inctax" placeholder="Income Tax Post Retirement" value="<?php echo $erow['inctax']; ?>" required>
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                    <div class="input-group mb-3">
                                                        <div class="slidecontainer">
                                                            <input type="range" min="1" max="100" oninput="myFunction(this)" value="<?php echo $erow['inctax']; ?>" step="1" class="slider" id="incTaxRange" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="helpBlock" class="col-lg-6 form-text">
                                                    The proportion of retirement income that will be used to pay for federal, state and local income taxes. This can vary a lot depending on the source of your retirement funds.
                                                </div>
                                            </div>
                                            <hr class="my-3">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo">
                                            Lifetime Assumptions
                                        </button>
                                    </h2>
                                </div>
                                <div id="collapseTwo" class="collapse" data-parent="#accordionAssumptions">
                                    <div class="card-body">
                                        <div class="container">
                                            <h2>Life Expectancy Assumptions</h2>
                                            <hr>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <h4>Life Expectancy</h4>
                                                    <div class="input-group mb-3">
                                                        <input type="number" class="form-control" name="death_age" id="death_age" placeholder="Expected Age of Passing" value="<?php echo $erow['death_age']; ?>" required>
                                                        <span class="input-group-text">years</span>
                                                    </div>
                                                    <div class="input-group mb-3">
                                                        <div class="slidecontainer">
                                                            <input type="range" min="30" max="125" oninput="myFunction(this)" value="<?php echo $erow['death_age']; ?>" step="1" class="slider" id="deathAgeRange" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="helpBlock" class="col-lg-6 form-text">
                                                    This is when your savings will be fully spent unless you decide to leave an estate behind. If you're young and healthy, you should plan conservatively and plan to live 90 to 100 years.
                                                </div>
                                            </div>
                                            <hr class="my-3">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <h4>Size of Estate</h4>
                                                    <div class="input-group mb-3">
                                                        <span class="input-group-text">$</span>
                                                        <input type="number" class="form-control" name="estate_size" id="estate_size" placeholder="Estate Size" value="<?php echo $erow['estate_size']; ?>" required>
                                                    </div>
                                                    <div class="input-group mb-3">
                                                        <div class="slidecontainer">
                                                            <input type="range" min="0" max="1000000" oninput="myFunction(this)" value="<?php echo $erow['estate_size']; ?>" step="10000" class="slider" id="estateSizeRange" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="helpBlock" class="col-lg-6 form-text">
                                                    The size of the estate you'd like to leave behind. If your intent is to leave a gift to charity, consider a charitable gift annuity instead. The benefits are three-fold: preferable tax treatment, hedge your longevity risk and fulfill your calling to give back to the world all at once.
                                                </div>
                                            </div>
                                            <hr class="my-3">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <button class="btn btn-outline-info btn-lg btn-block" type="submit">When Will I Retire?</button>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
    <script src="assets/js/chartretirement.js"></script>
    <script>
        feather.replace()
    </script>
    <script>
        $.fn.digits = function() {
            return this.each(function() {
                $(this).text($(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
            })
        }
    </script>
    <script>
        function myFunction() {
            var sliderage = document.getElementById("ageRange");
            var slidernetworth = document.getElementById("netWorthRange");
            var slidercontribution = document.getElementById("contributionRange");
            var sliderspend = document.getElementById("spendRange");
            var sliderroi = document.getElementById("roiRange");
            var sliderinflation = document.getElementById("inflationRange");
            var sliderinctax = document.getElementById("incTaxRange");
            var sliderdeathage = document.getElementById("deathAgeRange");
            var sliderestatesize = document.getElementById("estateSizeRange");

            var ageRange = document.getElementById("age");
            var networthRange = document.getElementById("net_worth");
            var contributionRange = document.getElementById("contribution");
            var spendRange = document.getElementById("spend");
            var roiRange = document.getElementById("roi");
            var inflationRange = document.getElementById("inflation");
            var inctaxRange = document.getElementById("inctax");
            var deathageRange = document.getElementById("death_age");
            var estatesizeRange = document.getElementById("estate_size");

            ageRange.value = sliderage.value;
            networthRange.value = slidernetworth.value;
            contributionRange.value = slidercontribution.value;
            spendRange.value = sliderspend.value;
            roiRange.value = sliderroi.value;
            inflationRange.value = sliderinflation.value;
            inctaxRange.value = sliderinctax.value;
            deathageRange.value = sliderdeathage.value;
            estatesizeRange.value = sliderestatesize.value;

            sliderage.oninput = function() {
                ageRange.value = this.value;
            }
            slidernetworth.oninput = function() {
                networthRange.value = this.value;
            }
            slidercontribution.oninput = function() {
                contributionRange.value = this.value;
            }
            sliderspend.oninput = function() {
                spendRange.value = this.value;
            }
            sliderroi.oninput = function() {
                roiRange.value = this.value;
            }
            sliderinflation.oninput = function() {
                inflationRange.value = this.value;
            }
            sliderinctax.oninput = function() {
                inctaxRange.value = this.value;
            }
            sliderdeathage.oninput = function() {
                deathageRange.value = this.value;
            }
            sliderestatesize.oninput = function() {
                estatesizeRange.value = this.value;
            }
        }
    </script>
</body>

</html>