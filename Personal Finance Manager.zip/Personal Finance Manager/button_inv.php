<!-- Delete -->
<div class="modal fade" id="del<?php echo $row['ticker']; ?>" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Delete Investment</h5>
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<?php
				$del = mysqli_query($conn, "SELECT * from `investment` where ticker='" . $row['ticker'] . "'");
				$drow = mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5>
						<center>Are you sure you want to delete this investment from the list? This action cannot be undone.</center>
					</h5>
				</div>
			</div>
			<a href="delete_inv.php?id=<?php echo $row['ticker']; ?>" class="btn btn-danger">Delete</a>
		</div>
	</div>
</div>
<!-- /.modal -->

<!-- Edit -->
<div class="modal fade" role="dialog" id="edit<?php echo $row['ticker']; ?>" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Edit Investment</h5>
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<?php
				$edit = mysqli_query($conn, "SELECT * from `investment` where ticker='" . $row['ticker'] . "'");
				$erow = mysqli_fetch_array($edit);
				?>
				<div class="py-1">
					<form class="form" method="POST" action="edit_inv.php?id=<?php echo $erow['ticker']; ?>">
						<div class="col">
							<div class="row">
								<div class="col">
									<div class="form-group">
										<label>Symbol</label>
										<input class="form-control" type="text" name="ticker" id="ticker" value="<?php echo $erow['ticker']; ?>">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col">
									<div class="form-group">
										<label>Price at Investment</label>
										<input class="form-control" type="text" name="price" id="price" value="<?php echo $erow['price']; ?>">
									</div>
								</div>
								<div class="col">
									<div class="form-group">
										<label>Quantity</label>
										<input class="form-control" type="number" name="quantity" id="quantity" value="<?php echo $erow['quantity']; ?>">
									</div>
								</div>
							</div>
						</div>
				</div>
				<div class="row">
					<div class="col d-flex justify-content-end">
						<button class="btn btn-primary" type="submit">Save Changes</button>
					</div>
				</div>
				</form>
			</div>
		</div>
	</div>
</div>
</div>
<!-- /.modal -->