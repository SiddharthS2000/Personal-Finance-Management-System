<?php
    include('conn.php');
    $value=$_COOKIE["username"];
    if($value!=0){
        $sql="SELECT sum(`amount`) as sumcat,`category` from `expense` where `date_added` >  now() - INTERVAL ".$value." month group by `category`"; 
    }
    else{
        $sql="SELECT sum(`amount`) as sumcat,`category` from `expense` group by `category`"; 
    }
    $query = mysqli_query($conn,$sql);
    $json_array = array();  
    while($row = mysqli_fetch_assoc($query))  
    {  
         $json_array[] = $row;  
    }   
    echo json_encode($json_array);  
?>
