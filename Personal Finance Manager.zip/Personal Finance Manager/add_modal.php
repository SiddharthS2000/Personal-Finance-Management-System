<div class="modal fade" role="dialog" tabindex="-1" id="addnew">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Add Expense</h5>
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="py-1">
					<form class="form" method="POST" action="addnew.php">
						<div class="row">
							<div class="col">
								<div class="row">
									<div class="col">
										<div class="form-group">
											<label>Date</label>
											<input class="form-control" type="date" name="date_added" id="date_added" value="">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col">
										<div class="form-group">
											<label>Category</label>
											<select id="category" name="category" class="form-control">
												<option value="Food">Food</option>
												<option value="Transport">Transport</option>
												<option value="Utilities & Bills">Utilities & Bills</option>
												<option value="Personal">Personal</option>
												<option value="Clothing">Clothing</option>
												<option value="Entertainment">Entertainment</option>
												<option value="Miscellanous">Miscellanous</option>
											</select>
										</div>
									</div>
									<div class="col">
										<div class="form-group">
											<label>Memo</label>
											<input class="form-control" type="text" name="memo" id="memo" value="">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col">
										<div class="form-group">
											<label>Amount</label>
											<input class="form-control" type="number" name="amount" id="amount" value="">
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col d-flex justify-content-end">
								<button class="btn btn-primary" type="submit">Add Expense</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>