<?php
	include('conn.php');
	$ticker=$_GET['id'];
	mysqli_query($conn,"DELETE FROM `investment` where ticker='$ticker'");
	header('location:investment.php');
?>