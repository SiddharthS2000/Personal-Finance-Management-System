<?php
	include('conn.php');
	
	$ticker=$_GET['id'];
	
	if (isset($_POST['price'])) {
		$price = $_POST['price'];
	}
	if (isset($_POST['quantity'])) {
		$quantity = $_POST['quantity'];
	}
	$amount=$price*$quantity;
	
	mysqli_query($conn,"UPDATE `investment` set price='$price', quantity='$quantity', amount='$amount' where ticker='$ticker'");
	header('location:investment.php');

?>