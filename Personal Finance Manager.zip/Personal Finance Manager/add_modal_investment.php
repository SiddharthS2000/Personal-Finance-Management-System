<div class="modal fade" role="dialog" tabindex="-1" id="addnew_inv">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Add Investment</h5>
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="py-1">
					<form class="form" method="POST" action="addnew_inv.php">
						<div class="row">
							<div class="col">
								<div class="row">
									<div class="col">
										<div class="form-group">
											<label>Symbol/Name</label>
											<input class="form-control" type="text" name="ticker" id="ticker" value="">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col">
										<div class="form-group">
											<label>Stock</label>
											<select id="stockyn" name="category" class="form-control">
												<option value="Yes">Yes</option>
												<option value="No">No</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col">
										<div class="form-group">
											<label>Price at Investment</label>
											<input class="form-control" type="text" name="price" id="price" value="">
										</div>
									</div>
									<div class="col">
										<div class="form-group">
											<label>Quantity</label>
											<input class="form-control" type="number" name="quantity" id="quantity" value="">
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col d-flex justify-content-end">
								<button class="btn btn-primary" type="submit">Add Investment</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>