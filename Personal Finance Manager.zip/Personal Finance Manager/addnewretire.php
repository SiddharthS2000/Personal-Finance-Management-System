<?php
	include('conn.php');

	if (isset($_POST['net_worth'])) {
		$net_worth = $_POST['net_worth'];
	}
	if (isset($_POST['age'])) {
		$age = $_POST['age'];
	}
	if (isset($_POST['contribution'])) {
		$contribution = $_POST['contribution'];
	}
	if (isset($_POST['spend'])) {
		$spend = $_POST['spend'];
	}
	if (isset($_POST['roi'])){
		$roi = $_POST['roi'];
	}
	if (isset($_POST['inflation'])) {
		$inflation = $_POST['inflation'];
	}
	if (isset($_POST['inctax'])) {
		$inctax = $_POST['inctax'];
	}
	if (isset($_POST['death_age'])) {
		$death_age = $_POST['death_age'];
	}
	if (isset($_POST['estate_size'])) {
		$estate_size = $_POST['estate_size'];
	}
	$r = (1+$roi/100);
	$i = (1-$inflation/100);
	$t = (1-$inctax/100);

	$ret_age = ($spend*$death_age*$t*$i + $estate_size*$i*$t +$age*$contribution*$t*$i - $net_worth*$r)/($contribution*$r + $spend*$r);

	$pre_ret = $ret_age - $age;				#time between retirement and current age
	$post_ret = $death_age - $ret_age;      #time between death and retirement age

	$ret_amt = ($net_worth+$contribution*($pre_ret)*$t)*pow($i*$r, $pre_ret);

	mysqli_query($conn, "UPDATE `retire` set net_worth = '$net_worth',age = '$age', contribution = '$contribution', spend = '$spend', roi = '$roi', inflation = '$inflation', inctax = '$inctax', death_age = '$death_age', estate_size = '$estate_size', ret_age = '$ret_age', ret_amount='$ret_amt' where retirement_id = '1'");
	header('location:retirement.php');
?>
