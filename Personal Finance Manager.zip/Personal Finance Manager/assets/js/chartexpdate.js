$.post('getchartexpdate.php', function(data) {
    var amount = [];
    var date = [];
    var obj = JSON.parse(data);
    for (var i in obj) {
        amount.push(obj[i].amount);
        date.push(obj[i].date_added);
    }
    var ctx = document.getElementById("chartcategory").getContext('2d');
    var data = {
        datasets: [{
            data: amount,
            backgroundColor: '#91c6c1',
        }],
        labels: date
    };
    var mylineChart = new Chart(ctx, {
        type: 'line',
        data: data,
        options: {
            maintainAspectRatio: true,
            legend: {
                display: false
            },
            elements: {
                line: {
                    tension: 0 // disables bezier curves
                }
            },
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
});