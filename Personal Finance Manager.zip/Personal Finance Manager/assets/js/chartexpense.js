$.post('getchartexpense.php', function(data) {
    var categories = [];
    var sumcat = [];
    var centcat = [];
    var sum = 0;
    var obj = JSON.parse(data);
    for (var i in obj) {
        categories.push(obj[i].category);
        sumcat.push(obj[i].sumcat);
        centcat.push(obj[i].sumcat);
        sum += parseInt(obj[i].sumcat);
    }
    for (var i = 0, length = centcat.length; i < length; i++) {
        centcat[i] = (centcat[i] / sum * 100).toFixed(2);
    }
    document.getElementById("totexp").innerHTML = sum;
    //absolute value categorical expenditure
    var ctx = document.getElementById("chartexpense").getContext('2d');
    var data = {
        datasets: [{
            data: sumcat,
            backgroundColor: [
                '#009999', '#68b8be', '#84afa2', '#165b65', '#697d99', '#91c6c1', '#116a8f'
            ],
        }],
        labels: categories,
    };
    var barChart = new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {
            maintainAspectRatio: true,
            legend: {
                position: 'bottom',
                labels: categories
            }
        }
    });
    //percentage categorical expenditure
    var ctx2 = document.getElementById("chartexpensecent").getContext('2d');
    var data2 = {
        datasets: [{
            data: centcat,
            backgroundColor: [
                '#009999', '#68b8be', '#84afa2', '#165b65', '#697d99', '#91c6c1', '#116a8f'
            ],
        }],
        labels: categories,
    };
    var pieChart = new Chart(ctx2, {
        type: 'pie',
        data: data2,
        options: {
            maintainAspectRatio: true,
            legend: {
                position: 'bottom',
                labels: {
                    boxWidth: 12
                }
            }
        }
    });
});