var i, age, death_age, ret_age, contribution, spend, net_worth, age, roi, inflation, inctax, estate_size, ret_amt;
var age_array = [];
var amt_array = [];
$.post('getchartretirement.php', function(data) {
    var obj = JSON.parse(data);
    for (var i in obj) {
        age = parseInt(obj[i].age);
        death_age = parseInt(obj[i].death_age);
        ret_age = parseInt(obj[i].ret_age);
        contribution = parseInt(obj[i].contribution);
        spend = parseInt(obj[i].spend);
        net_worth = parseInt(obj[i].net_worth);
        age = parseInt(obj[i].age);
        roi = parseFloat(1 + obj[i].roi / 100);
        inflation = parseFloat(1 - obj[i].inflation / 100);
        inctax = parseFloat(1 - obj[i].inctax / 100);
        estate_size = parseInt(obj[i].estate_size);
    }

    i = parseInt(age);
    while (i <= death_age) {
        age_array.push(i);
        i += 2;
    }

    let pre_ret = parseInt(ret_age - age);
    let post_ret = parseInt(death_age - ret_age);

    function ret_amt1(x) {
        return (net_worth + contribution * x * inctax) * Math.pow(roi * inflation, x);
    }

    for (var i = 0; i < pre_ret; i += 2) {
        amt_array.push(ret_amt1(i));

    }

    function ret_amt2(x) {
        if (x < post_ret)
            return (ret_amt1(pre_ret) - spend * x * Math.pow(inflation, x));
        else
            return estate_size * Math.pow(inflation, post_ret);
    }

    for (var i = 0; i < post_ret; i += 2) {
        amt_array.push(ret_amt2(i));
    }


    var ctx = document.getElementById("chartretirement").getContext('2d');
    var data = {
        datasets: [{
            data: amt_array,
            pointRadius: 5,
            pointStyle: 'triangle'
        }],
        labels: age_array
    };
    var myDoughnutChart = new Chart(ctx, {
        type: 'line',
        data: data,
        options: {
            maintainAspectRatio: true,
            legend: {
                display: false
            },
        }
    });
});