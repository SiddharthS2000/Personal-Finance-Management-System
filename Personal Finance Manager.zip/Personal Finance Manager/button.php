<!-- Delete -->
<div class="modal fade" id="del<?php echo $row['expense_id']; ?>" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Delete Expense</h5>
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<?php
				$del = mysqli_query($conn, "SELECT * from `expense` where expense_id='" . $row['expense_id'] . "'");
				$drow = mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5>
						<center>Are you sure you want to delete this transaction from the list? This action cannot be undone.</center>
					</h5>
				</div>
			</div>
			<a href="delete.php?id=<?php echo $row['expense_id']; ?>" class="btn btn-danger">Delete</a>
		</div>
	</div>
</div>
<!-- /.modal -->

<!-- Edit -->
<div class="modal fade" role="dialog" id="edit<?php echo $row['expense_id']; ?>" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Edit Expense</h5>
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<?php
				$edit = mysqli_query($conn, "SELECT * from `expense` where expense_id='" . $row['expense_id'] . "'");
				$erow = mysqli_fetch_array($edit);
				?>
				<div class="py-1">
					<form class="form" method="POST" action="edit.php?id=<?php echo $erow['expense_id']; ?>">
						<div class="col">
							<div class="row">
								<div class="col">
									<div class="form-group">
										<label>Date</label>
										<input class="form-control" type="date" name="date_added" id="date_added" value="<?php echo $erow['date_added']; ?>">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col">
									<div class="form-group">
										<label>Category</label>
										<select class="form-control" name="category" id="category" value="<?php echo $erow['category']; ?>">
											<option value="Food">Food</option>
											<option value="Transport">Transport</option>
											<option value="Utilities & Bills">Utilities & Bills</option>
											<option value="Personal">Personal</option>
											<option value="Clothing">Clothing</option>
											<option value="Entertainment">Entertainment</option>
											<option value="Miscellanous">Miscellanous</option>
										</select>
									</div>
								</div>
								<div class="col">
									<div class="form-group">
										<label>Memo</label>
										<input class="form-control" type="text" name="memo" id="memo" value="<?php echo $erow['memo']; ?>">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col">
									<div class="form-group">
										<label>Amount</label>
										<input class="form-control" type="text" name="amount" id="amount" value="<?php echo $erow['amount']; ?>">
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col d-flex justify-content-end">
								<button class="btn btn-primary" type="submit">Save Changes</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /.modal -->