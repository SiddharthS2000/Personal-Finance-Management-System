<?php
    include('conn.php');
    $value=$_COOKIE["username"];
    if($value!=0){
        $sql="SELECT sum(`amount`) as amount,`date_added` from `expense` where `date_added` >  now() - INTERVAL ".$value." month group by `date_added`"; 
    }
    else{
        $sql="SELECT sum(`amount`) as amount,`date_added` from `expense` group by `date_added`"; 
    }
    $query = mysqli_query($conn,$sql);
    $json_array = array();  
    while($row = mysqli_fetch_assoc($query))  
    {  
         $json_array[] = $row;  
    }   
    echo json_encode($json_array);  
?>
