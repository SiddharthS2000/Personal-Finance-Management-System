<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Plutus</title>

    <!-- Bootstrap core CSS -->
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-49548145-2"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'UA-49548145-2');
    </script>

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>


    <!-- Custom styles for this template -->
    <link href="assets/css/dashboard.css" rel="stylesheet">
</head>

<body>

    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="#">PLUTUS</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse" data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <span data-feather="home"></span> Dashboard <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="expense.php">
                                <span data-feather="file"></span> Expense Manager
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="retirement.php">
                                <span data-feather="shopping-cart"></span> Retirement Calculator
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="investment.php">
                                <span data-feather="shopping-cart"></span> Investment Portfolio
                            </a>
                        </li>
                    </ul>
                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Investment Advice</span>
                    </h6>
                    <ul class="nav flex-column mb-2">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                Stock Prediciton Tool
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>STOCK PREDICTION TOOL</h1>
                </div>
                <div class="jumbotron">
                    <h1 class="display-4">Track Your Investments!</h1>
                    <p class="lead">The stock market is known as a place where people can make a fortune if they can crack the mantra to successfully predict stock prices. Try our stock predictor to see if that investment is the right choice.</p>
                    <hr class="my-4">
                    <div class="container">
                        <div class="accordion" id="div_data">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Stock Data</h5>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="form-row">
                                            <label>Ticker Symbol</label>
                                            <input class="form-control" name="input_ticker" id="input_ticker" placeholder="example: MSFT" value="MSFT">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>API Key</label>
                                                <input class="form-control" name="input_apikey" type="text" id="input_apikey" placeholder="Input your API key or use 'demo'" value="OPUZPFM1P44L15VV">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Data Temporal Resolutions</label>
                                                <select class="form-control" onchange="onClickChangeDataFreq(this)">
                                                    <option value="Weekly" onchange="onClickChangeDataFreq('Weekly')" selected>Weekly</option>
                                                    <option value="Daily" onchange="onClickChangeDataFreq('Daily')">Daily</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row" id="div_container_getdata">
                                        <div class="col">
                                            <button class="btn btn-outline-dark btn-block" id="btn_fetch_data" onclick="onClickFetchData()">Fetch Data</button>
                                            <hr>
                                            <div id="load_fetch_data" style="display:none"></div>
                                        </div>
                                    </div>
                                    <div class="form-row" id="div_container_linegraph" style="display:none">
                                        <div class="col">
                                            <div class="card">
                                                <div class="card-body">
                                                    <span class="card-header" id="div_linegraph_data_title">Card Title</span>
                                                    <div>
                                                        <div id="div_linegraph_data" style="width:100%; height:350px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!-- E Get Stocks Data -->

                            <hr class="my-4">

                            <div class="card" id="div_sma">
                                <div class="card-header">
                                    <h5 class="card-title">Simple Moving Average</h5>
                                </div>
                                <div class="card-body">
                                    <div class="form-row" id="div_container_getsmafirst">
                                        <div class="col">
                                            <p>Please <a href="#div_data">retrieve stocks data</a> before proceeding to calculate SMA.</p>
                                        </div>
                                    </div>
                                    <div class="form-group row" id="div_container_getsma" style="display:none">
                                        <div class="col-sm-2 col-form-label">
                                            <label>Window Size
                                                <small class="form-text">This is the "time window" for SMA</small>
                                            </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input class="form-control" type="number" id="input_windowsize" placeholder="Time Window" value="20">
                                        </div>
                                        <div class="col">
                                            <button class="btn btn-outline-dark btn-block" id="btn_draw_sma" onclick="onClickDisplaySMA()">Compute SMA</button>
                                            <div id="load_draw_sma" style="display:none"></div>
                                        </div>
                                    </div>
                                    <div class="form-row" id="div_container_sma" style="display:none">
                                        <div class="col">
                                            <div class="card">
                                                <div class="card-body">
                                                    <span class="card-title" id="div_linegraph_sma_title"></span>
                                                    <div id="div_linegraph_sma" style="width:100%; height:350px;"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!---
                                    <hr class="my-4">
                                    <div class="form-row" id="div_container_trainingdata" style="display:none">
                                        <div class="col">
                                            <div class="card">
                                                <div class="card-body">
                                                    <span class="card-title">Training Data (top 25 rows)</span>
                                                    <div style="overflow-x: scroll;" id="div_trainingdata">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    -->
                                </div>
                            </div>
                            <!-- E Simple Moving Average -->

                            <hr class="my-4">

                            <div class="card" id="div_train">
                                <div class="card-header">
                                    <h5 class="card-title">Train Neural Network</h5>
                                </div>
                                <div class="card-body">
                                    <div id="div_container_train" style="display:none">
                                        <div class="form-group">
                                            <div class="form-row">
                                                <div class="col">
                                                    <p>
                                                        <!-- [how to use, what you want your reader to do after you end, as simple and obvious] -->
                                                        You may tweak the hyperparameters and then hit the <i>Begin Training Model</i> button to train the
                                                        model.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-row">
                                                <div class="col">
                                                    <label for="input_trainingsize">Training Dataset Size (%)</label>
                                                    <input class="form-control" type="number" id="input_trainingsize" placeholder="a number between (1-99)" value="98">
                                                </div>
                                                <div class="col">
                                                    <label for="input_epochs">Epochs</label>
                                                    <input class="form-control" type="number" id="input_epochs" placeholder="a number" value="10">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-row">
                                                <div class="col">
                                                    <label for="input_learningrate">Learning Rate</label>
                                                    <input class="form-control" type="number" id="input_learningrate" placeholder="a decimal" value="0.01">
                                                    <small class="form-text text-muted">Typically range between 0.01 and 0.1</small>
                                                </div>
                                                <div class="col">
                                                    <label for="input_hiddenlayers">Hidden LSTM Layers</label>
                                                    <input class="form-control" type="number" id="input_hiddenlayers" placeholder="a number'" value="4">
                                                    <small class="form-text text-muted">Number of LSTM layers</small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <button class="btn btn-outline-dark btn-block" id="btn_draw_trainmodel" onclick="onClickTrainModel()">Begin Training Model</button>
                                        </div>
                                    </div>
                                    <div class="form-row" id="div_container_training" style="display:none">
                                        <div class="col">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5 class="card-title">Progress</h5>
                                                </div>
                                                <div class="card-body">
                                                    <hr />
                                                    <div class="progress">
                                                        <div class="determinate" id="div_training_progressbar" style="width: 100%"></div>
                                                    </div>
                                                    <hr />
                                                    <h6>Loss</h6>
                                                    <div id="div_linegraph_trainloss" style="width:100%; height:250px;"></div>
                                                    <hr />
                                                    <h6>Logs</h6>
                                                    <div id="div_traininglog" style="overflow-x: scroll; overflow-y: scroll; height: 250px;"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- E Train Neural Network -->

                            <hr class="my-4">

                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Model Validation</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row" id="div_container_validate" style="display:none">
                                        <div class="col">
                                            <p>
                                                <!-- [how to use, what you want your reader to do after you end, as simple and obvious] -->
                                                Hit the <i>Validate Model</i> button to see how this model performs. Whohoo!
                                            </p>
                                        </div>
                                        <div class="col">
                                            <button class="btn btn-outline-dark btn-block" id="btn_validation" onclick="onClickValidate()">Validate
                                                Model</button>
                                            <div class="spinner-border" id="load_validating" style="display:none"></div>
                                        </div>
                                    </div>
                                    <div class="row" id="div_container_validating" style="display:none">
                                        <div class="col">
                                            <div class="card">
                                                <div class="card-body">
                                                    <span class="card-title" id="div_predict_title">Compare True values to Predicted
                                                        values</span>
                                                    <div id="div_validation_graph"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!-- E Validation -->

                            <hr class="my-4">

                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Make Prediction</h5>
                                </div>
                                <div class="card-body">
                                    <p>
                                        <!-- [purpose of this step, fun for the reader] -->
                                        Finally, the model has been validated and the predicted values map closely to its true values, we shall use it
                                        to predict the future. We will apply the same model.predict function and use the last {{input_windowsize}}
                                        data points as the input, because that is our window size. This means that, if our training data is increment
                                        daily, we will use the past {{input_windowsize}} days as input, to predict the next day.
                                    </p>
                                    <span class="card-title">Try It</span>
                                    <div class="row" id="div_container_predictfirst">
                                        <div class="col">
                                            <p>Don’t have a model to perform prediction? <a href="#div_train">Train your model</a>.</p>
                                        </div>
                                    </div>
                                    <div class="row" id="div_container_predict" style="display:none">
                                        <div class="col">
                                            <p>
                                                <!-- [how to use, what you want your reader to do after you end, as simple and obvious] -->
                                                Hit the <i>Validate Model</i> button to see how this model performs. Whohoo!
                                            </p>
                                        </div>
                                        <div class="col">
                                            <button class="btn btn-outline-dark btn-block" id="btn_prediction" onclick="onClickPredict()">Make
                                                Prediction</button>
                                            <div class="spinner-border" id="load_predicting" style="display:none"></div>
                                        </div>
                                    </div>
                                    <div class="row" id="div_container_predicting" style="display:none">
                                        <div class="col">
                                            <div class="card">
                                                <div class="card-body">
                                                    <span class="card-title" id="div_predict_title">Predicted</span>
                                                    <div id="div_prediction_graph"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <?php include('add_modal_stock.php'); ?>

    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@1.0.0/dist/tf.min.js"></script>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>

    <script src="assets/js/model.js"></script>
    <script src="assets/js/index.js"></script>

    <script>
        $(document).ready(function() {
            $('.tooltipped').tooltip();
            $('.scrollspy').scrollSpy();
            $('.sidenav').sidenav();
        });
    </script>
</body>

</html>