<?php
	include('conn.php');
	if (isset($_POST['ticker'])) {
		$ticker = $_POST['ticker'];
	}
	$query = mysqli_query($conn, "SELECT * from `stock` where `ticker`='$ticker'");
	if (mysqli_num_rows($query) == 0) {
		$url = 'https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=' . $ticker . '&interval=5min&apikey=OPUZPFM1P44L15VV';
		$url2 = 'https://www.alphavantage.co/query?function=OVERVIEW&symbol=' . $ticker . '&apikey=OPUZPFM1P44L15VV';
		$json = file_get_contents($url);
		$json2 = file_get_contents($url2);
		$arr = json_decode($json, TRUE);
		$arr2 = json_decode($json2, TRUE);
		// check if the array key exists
		if (!empty($arr['Time Series (5min)'])) {
			// loop over the contents of Time Series
			$array1 = array();
			foreach ($arr['Time Series (5min)'] as $date => $results) {
				// loop over the results for each date in Time Series
				foreach ($results as $key => $value) {
					$array1[$key] = $value;
				}
				$open = $array1['1. open'];
				$high = $array1['2. high'];
				$low = $array1['3. low'];
				$close = $array1['4. close'];
				$volume = $array1['5. volume'];
				$name = $arr2['Name'];
				$market_cap = $arr2['MarketCapitalization'];
				mysqli_query($conn, "INSERT INTO `stock` (`ticker`,`name`,`open`,`high`,`low`,`close`,`market_cap`,`volume`)
												VALUES ('$ticker','$name','$open','$high','$low','$close','$market_cap','$volume')");
			}
		}
	} else {
		$url = 'https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=' . $ticker . '&interval=5min&apikey=OPUZPFM1P44L15VV';
		$url2 = 'https://www.alphavantage.co/query?function=OVERVIEW&symbol=' . $ticker . '&apikey=OPUZPFM1P44L15VV';
		$json = file_get_contents($url);
		$json2 = file_get_contents($url2);
		$arr = json_decode($json, TRUE);
		$arr2 = json_decode($json2, TRUE);
		// check if the array key exists
		if (!empty($arr['Time Series (5min)'])) {
			// loop over the contents of Time Series
			$array1 = array();
			foreach ($arr['Time Series (5min)'] as $date => $results) {
				// loop over the results for each date in Time Series
				foreach ($results as $key => $value) {
					$array1[$key] = $value;
				}
				$open = $array1['1. open'];
				$high = $array1['2. high'];
				$low = $array1['3. low'];
				$close = $array1['4. close'];
				$volume = $array1['5. volume'];
				$name = $arr2['Name'];
				$market_cap = $arr2['MarketCapitalization'];
			mysqli_query($conn, "UPDATE `stock` set `name`='$name', `open`='$open',`high`='$high',`low`='$low',`close`='$close',`market_cap`='$market_cap',`volume`='$volume' where `ticker`='$ticker'");
			}
		}
	}
	header('location:investment.php');
?>
