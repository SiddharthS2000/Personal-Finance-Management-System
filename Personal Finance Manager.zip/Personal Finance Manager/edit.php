<?php
	include('conn.php');
	
	$expense_id=$_GET['id'];
	
	if (isset($_POST['date_added'])) {
		$date_added = $_POST['date_added'];
	}
	if (isset($_POST['category'])) {
		$category = $_POST['category'];
	}
	if (isset($_POST['memo'])) {
		$memo = $_POST['memo'];
	}
	if (isset($_POST['amount'])) {
		$amount = $_POST['amount'];
	}
	
	mysqli_query($conn,"UPDATE `expense` set date_added='$date_added', category='$category', memo='$memo', amount='$amount' where expense_id='$expense_id'");
	header('location:expense.php');

?>