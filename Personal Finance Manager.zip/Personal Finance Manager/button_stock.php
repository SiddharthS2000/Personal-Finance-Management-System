<!-- Delete -->
<div class="modal fade" id="del_stock<?php echo $row['ticker']; ?>" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Delete Investment</h5>
				<button type="button" class="close" data-dismiss="modal">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<?php
				$del = mysqli_query($conn, "SELECT * from `stock` where ticker='" . $row['ticker'] . "'");
				$drow = mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5>
						<center>Are you sure you want to delete this stock from the list? This action cannot be undone.</center>
					</h5>
				</div>
			</div>
			<a href="delete_stock.php?id=<?php echo $row['ticker']; ?>" class="btn btn-danger">Delete</a>
		</div>
	</div>
</div>
<!-- /.modal -->