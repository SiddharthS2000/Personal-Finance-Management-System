<?php
    include('conn.php');
    setcookie("username",1);
    if (isset($_POST['buttontimeperiod'])) {
		$value = $_POST['buttontimeperiod'];
        setcookie("username",$value);
	}
    header('location:expense.php');
?>
