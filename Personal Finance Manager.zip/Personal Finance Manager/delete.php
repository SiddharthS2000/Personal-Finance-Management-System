<?php
	include('conn.php');
	$expense_id=$_GET['id'];
	mysqli_query($conn,"DELETE FROM `expense` where expense_id='$expense_id'");
	header('location:expense.php');
?>