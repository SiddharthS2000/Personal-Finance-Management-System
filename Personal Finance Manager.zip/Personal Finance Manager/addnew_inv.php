<?php
	include('conn.php');
	
	if (isset($_POST['ticker'])) {
		$ticker = $_POST['ticker'];
	}
	if (isset($_POST['price'])) {
		$price = $_POST['price'];
	}
	if (isset($_POST['quantity'])) {
		$quantity = $_POST['quantity'];
	}

    $amt = $price * $quantity;

	mysqli_query($conn,"INSERT INTO `investment` (ticker,price,quantity,amount)
	VALUES ('$ticker','$price','$quantity','$amt')");
	header('location:investment.php');
?>