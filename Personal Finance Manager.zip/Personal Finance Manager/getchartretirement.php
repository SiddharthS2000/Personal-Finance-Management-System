<?php
    include('conn.php');

    $query = mysqli_query($conn, "SELECT `retirement_id`, `net_worth`, `age`, `contribution`, `spend`, `roi`, `inflation`, `inctax`, `death_age`, `estate_size`, `ret_age`, `ret_amount` from `retire`");
    $json_array = array();  
    while($row = mysqli_fetch_assoc($query))  
    {  
         $json_array[] = $row;  
    }   
    echo json_encode($json_array);  
?>
